import functions_framework

# Decoratore per definire una funzione HTTP
@functions_framework.http
def main(request):
    """
    Cloud Function di esempio che gestisce una richiesta HTTP.

    Args:
        request (flask.Request): L'oggetto request di Flask contenente i dati della richiesta HTTP.

    Returns:
        flask.Response: L'oggetto response di Flask con una risposta HTTP.
    """
    # Estrarre i dati dal corpo della richiesta (se necessario)
    request_json = request.get_json(silent=True)
    request_args = request.args

    # Logica di esempio
    if request_json and 'name' in request_json:
        name = request_json['name']
    elif request_args and 'name' in request_args:
        name = request_args['name']
    else:
        name = 'World'

    # Creazione della risposta
    response_message = f'Hello, {name}!'
    
    # Restituzione della risposta come JSON
    return {
        'message': response_message
    }